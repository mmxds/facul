#Crie um loop for que imprima os números de 10 a 1 em ordem decrescente.

for i in range(10, 1, -1):
    print(i)


