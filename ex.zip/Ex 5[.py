#Use a função range() e um loop for para imprimir os números de 0 a 20 com um passo de 3.

for i in range(0, 20, 3):
    print(i)