#Escreva um programa que use um loop for para imprimir os números de 1 a 10.

for i in range(1, 11):
    print(i)