#Escreva um loop for que imprima apenas os números pares de 1 a 20.

for i in range(2, 21, 2):
    print(i)
