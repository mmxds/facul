inicio = int (input("Digite o inicio"))
fim = int (input("Digite o fim"))
passo = int (input("Digite o passo"))
acum=0
for i in range(0, fim, 1):
    if i%2=0:
        print (1)
acum+=i
print(f"Soma dos valores igual ={acum}")
