#Use a função range() e um loop for para imprimir os números ímpares entre 1 e 20.

for i in range(1, 20, 2):
    print(i)